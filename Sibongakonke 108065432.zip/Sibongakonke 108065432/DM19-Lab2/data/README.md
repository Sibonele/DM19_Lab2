### The dataset we use in Lab2

Dataset: [SemEval 2017 Task](https://competitions.codalab.org/competitions/16380)